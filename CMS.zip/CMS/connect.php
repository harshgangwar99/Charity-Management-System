<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'WFM');

if(isset($_POST['submit']))
{
    $Name = $_POST['Name'];
    $number = $_POST['number'];
    $address = $_POST['address'];
    $message = $_POST['message'];
    $donations = $_POST['donations'];

    $query = "INSERT INTO `details`(`Name`,`number`,`address`,`message`,`donations`) VALUES (`$Name`,`$number`,`$address`,`$message`,`$donations`)";
    $query_run = mysqli_query($connection,$query);

    if($query_run)
    {
        echo '<script type="text/javascript"> alert("Data Saved")</script>';
    }
    else{
        echo '<script type="text/javascript"> alert("Data Not Saved")</script>';   
    }
    
}

/*$Name = $_POST['Name'];
$number = $_POST['number'];
$address = $_POST['address'];
$message = $_POST['message'];
$donations = $_POST['donations'];

$connection = new mysqli('localhost','root','','WFM');
if($connection->connect_error){
    die('connection failed :'.$connection->connect_error);
}
else{
    $stmt = $connection->prepare("insert into details(Name,number,address,message,donations)
                    values(?,?,?,?,?)");
    $stmt->bind_param("sisss",$Name,$number,$address,$message,$donations);
    $stmt->execute();
    echo "Thank you for your details...";
    $stmt->close();
    $connection->close();
}*/
?>